<DOCTYPE html>
<html>
<head> 
<meta charset="utf-8">
<title>cdoernsearchengine</title>
</head>
<body>
<div style="width: 600px; margin: 10px auto"> 
<h1>"cdoern.com search engine"</h1> 
<form action="search.php" method="get"> 
<input type="text" style="width: 100%; font-size: 16px;" name="q" value="" placeholder="Search here!"> 
<div style="text-align: center"><input type="submit" style="font-size: 16px; margin-top:" name="search" value="Search"> 
</form> 
</div> 
</body> 
</html> 